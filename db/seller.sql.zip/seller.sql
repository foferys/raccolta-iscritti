-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Nov 19, 2024 alle 14:51
-- Versione del server: 10.4.28-MariaDB
-- Versione PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `seller`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `sellers`
--

CREATE TABLE `sellers` (
  `id` int(11) NOT NULL,
  `nomeOrg` varchar(255) NOT NULL,
  `partecipante` varchar(255) NOT NULL,
  `ruolo` varchar(255) NOT NULL,
  `secondoPartecipante` varchar(255) NOT NULL,
  `indirizzo` varchar(255) NOT NULL,
  `telefono` varchar(255) NOT NULL,
  `sito` varchar(255) NOT NULL,
  `tipoOrg` varchar(255) NOT NULL,
  `struttRicett` varchar(255) NOT NULL,
  `tipOfferta` varchar(255) NOT NULL,
  `tipClientela` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `sellers`
--

INSERT INTO `sellers` (`id`, `nomeOrg`, `partecipante`, `ruolo`, `secondoPartecipante`, `indirizzo`, `telefono`, `sito`, `tipoOrg`, `struttRicett`, `tipOfferta`, `tipClientela`) VALUES
(1, 'Eva', 'Sbarra', 'CEO', ' ', 'contrada cimino 55 B ', '3383156010', 'www.primacom.cloud', 'Albergo', 'hotel', 'evento sportivo', 'famiglie');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `token` varchar(155) DEFAULT NULL,
  `reg_date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `email`, `password`, `token`, `reg_date`) VALUES
(2, 'foferys@gmail.com', '$2y$10$EF9EyNc1RhfvOlIg5Wjrm.etRtJbpbgurSbNfPLsT5Gc8zUhZYMEa', 'e1e7d1bd9d3c4c8b376d3f210115cacd3ab0086142c7ac02836ddbc87f79b777', '2023-11-02 12:43:57');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `sellers`
--
ALTER TABLE `sellers`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `sellers`
--
ALTER TABLE `sellers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
